const Loading = () => {
  return (
    <div className="w-screen h-screen flex justify-center items-center fixed inset-0">
      <div className="lds-grid">
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
      </div>
    </div>
  );
};

export default Loading
