"use client";

import withPartner from "./withPartner";

const Layout = ({ children }) => {
  return <div className="">{children}</div>;
};

export default withPartner(Layout);
